package com.example.macrochallenge9

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ScrollPopulerWisata : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_scroll_populer_wisata)

    }
}